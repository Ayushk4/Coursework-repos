
#include <stdio.h> 
#include <string.h>
#include <arpa/inet.h>
 
#include "rsocket.h"

#define MAX 100 
#define ROLLNO 30008



int main(int argc,  char **argv ) { 
  
    // Creating socket file descriptor
    struct sockaddr_in mesg_addr; 
    socklen_t len; 
    char buffer[MAX] ;	 
    int sockfd = r_socket(AF_INET, SOCK_MRP, 0);
    if ( sockfd < 0 ) { 
        perror("socket creation failed"); 
        exit(1); 
    } 
    printf("Enter word of atleast one character:");
    scanf(" %[^\n]",buffer);
    //printf("$%s %d$",buffer,strlen(buffer));	
    memset(&mesg_addr, 0, sizeof(mesg_addr)); 

    	

    mesg_addr.sin_family = AF_INET; 
    mesg_addr.sin_port = htons(5000+2*ROLLNO); 
    mesg_addr.sin_addr.s_addr = INADDR_ANY;

    if (r_bind(sockfd, (const struct sockaddr *)&mesg_addr, sizeof(mesg_addr)) < 0 ) { 
        perror("bind failed"); 
        r_close(sockfd);
        exit(EXIT_FAILURE); 
    }
    mesg_addr.sin_port = htons(5000+2*ROLLNO+1);
	
    char msg[20];
    msg[0]='$'; 	
    sprintf(msg+1,"%ld",strlen(buffer));
    //printf("%s\n",msg);
    len = sizeof(mesg_addr);		 
    r_sendto(sockfd,(const char*)msg,strlen(msg),0,(const struct sockaddr *)&mesg_addr,len);	
    for(int i = 0;i<strlen(buffer);i++){  
        

        r_sendto(sockfd, (const char *)(buffer+i), 1, 0,(const struct sockaddr *) &mesg_addr, len);
    }
    int trans=r_close(sockfd);
    printf("Average number of transmissions per character=%f",(float)trans/strlen(buffer));
    return 0; 
}
