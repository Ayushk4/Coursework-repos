//rsocket.h file


#ifndef RSOCKET_H
#define RSOCKET_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/select.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/time.h>
#include<signal.h>
#include<limits.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>



#define P 0.2
#define SOCK_MRP 20
#define T_SEC 2
#define T_USEC 0
#define MAX 100

//Function prototypes

int r_socket(int dom, int type, int prot);
int r_bind(int sockfd, const struct sockaddr* addr, socklen_t addrlen);
void push();
int r_sendto(int sockfd, const void *buf, size_t len, int flags, const struct sockaddr *dest_addr, socklen_t addrlen);
int r_recvfrom(int sockfd, char *buf, size_t len, int flags, struct sockaddr *source_addr, socklen_t *addrlen);
void pop();
int r_close(int sockfd);
int dropMessage(float p);
int getid(char *msg);
void HandleReceive();
void HandleACKMsgRecv(char buf[103]);
void HandleAppMsgRecv(char buf[103],struct sockaddr *source_addr,socklen_t addrlen);
void assign_id(char *msg,char c,int x);
void HandleRetransmit();
void HandleTransmit();





//Data structures
struct recvmsg{
	char msg[100];					//for receive buffer
	struct sockaddr addr;
};

struct sendmsg
{
	char msg[103];					//for send buffer
	struct sockaddr addr;
	int id;	
};

struct queue
{
	int recvbuffer_recvend;					//receive buffer start and end
	int recvbuffer_addend;
};

struct notackmes{					//for unacknowledged msg
	int id;
	time_t stime;
	struct sockaddr addr;
	int flags;
	char msg[100];
	
};

#endif