//rsocket.c file

#include "rsocket.h"
int check=0;
struct recvmsg *recvbuffer;			//Receive buffer
struct sendmsg *sendbuffer;			//Send buffer
struct notackmes *notackmestb;		//Unacknowledged msg table
int *recvmsgidtb;					//Received msg id table

int available_id;					//available_id to assign ids

int transmissions;				//number of transmissions

struct queue queue1;
int sendbuffer_size;
int sockfd_udp;						//udp socket
struct sockaddr addr1;
int size_notackmestb;				//size of tables

void push()
{
	queue1.recvbuffer_addend=(queue1.recvbuffer_addend+1)%MAX;
}

void pop()
{
	queue1.recvbuffer_recvend=(queue1.recvbuffer_recvend+1)%MAX;
}

int getid(char *msg)
{
	int id=0;
	id=(msg[5]-'0')*1+(msg[4]-'0')*10+(msg[3]-'0')*100+(msg[2]-'0')*1000+(msg[1]-'0')*10000+(msg[0]-'0')*100000;
	return id;
}

int r_bind(int sockfd_udp, const struct sockaddr* addr, socklen_t addrlen)
{
	if(bind(sockfd_udp,addr,addrlen)<0)	//bind the udp socket 
	{
		return -1;	//failure
	}
	return 0;	//success
}

void assign_id(char *msg,char c,int x)
{
	msg[0]=c;
	msg[6]=x%10+'0';
	x=x/10;
	msg[5]=x%10+'0';
	x=x/10;
	msg[4]=x%10+'0';
	x=x/10;
	msg[3]=x%10+'0';
	x=x/10;
	msg[2]=x%10+'0';
	x=x/10;
	msg[1]=x%10+'0';
	//printf("msg=%s\n",msg);
}


void HandleTransmit()
{
	int i=0;
	//printf("OOOOO\n");
	int min=INT_MAX;
	int index=-1;
	
	if(size_notackmestb>=100)
	{

	  
		return;
	}	
	if(sendbuffer_size==0)
	{
		//printf("AAA\n");
		
		return;
	}	

		for(i=0;i<MAX;i++)
		{
			if(min>sendbuffer[i].id && sendbuffer[i].id!=-1)
			{
				
				min=sendbuffer[i].id;
				index=i;

			}

		}	
	//printf("Fine\n");
	struct sockaddr addr=sendbuffer[index].addr;
	addr1=addr;
	int n=sendto(sockfd_udp,sendbuffer[index].msg,strlen(sendbuffer[index].msg),MSG_DONTWAIT,(const struct sockaddr *)&addr, sizeof(addr));
	//printf("$$%s$$\n",sendbuffer[index].msg);
	if(n!=-1)
	{
		sendbuffer_size--;
		transmissions++;
		
		
		
		int k=0;
		while(notackmestb[k].id!=-1)
			k++;
		notackmestb[k].id=sendbuffer[index].id;
		
		sendbuffer[index].id=-1;
		notackmestb[k].flags=MSG_DONTWAIT;
		
		strcpy(notackmestb[k].msg,sendbuffer[index].msg+7);
		
		notackmestb[k].stime=time(NULL);
		notackmestb[k].addr=addr;
		
		size_notackmestb++;
		//printf("Bye\n");
		//printf("send_size=%d ack_size=%d\n",sendbuffer_size,size_notackmestb);
	}	
}

void HandleRetransmit()			//Handling retransmission 
{
	time_t curr_time;
	curr_time=time(NULL);		//get the current time
	int i;
	char buf[MAX+7];
	struct sockaddr addr;
	

	for(i=0;i<MAX;i++)			
	{
				
			if(notackmestb[i].id!=-1 && (notackmestb[i].stime+T_SEC)<=curr_time)	//Timeout condition
			{
				memset(buf,'\0',MAX+7);		
				assign_id(buf,'m',notackmestb[i].id);
				//printf("HandleRetransmit=%s %d %s\n",buf,notackmestb[i].id,notackmestb[i].msg);
				strcat(buf,notackmestb[i].msg);		
				addr=notackmestb[i].addr;
				//printf("##%s##\n",buf);
				sendto(sockfd_udp,buf,strlen(buf),notackmestb[i].flags,(const struct sockaddr *)&addr, sizeof(addr));
				transmissions++;				
				
				notackmestb[i].stime = curr_time;				//resetting time
				
			}
			
		
	}
	return;			
}


void HandleReceive()				//Handle the received message
{
	char buf[MAX+7];				
	int n;
	struct sockaddr source_addr;	
	socklen_t addrlen;

	addrlen=sizeof(source_addr);
	memset(buf,0,MAX+7);	  
		
	n=recvfrom(sockfd_udp,buf,MAX+7,MSG_DONTWAIT,(struct sockaddr *)&source_addr,&addrlen);	
	//printf("%s\n",buf );
	if(n<7) return;
	buf[n]='\0';
	if(strcmp("CLOSING",buf)==0)
	{
		strcpy(recvbuffer[queue1.recvbuffer_recvend].msg,buf);
		push();
		return;	
	}	
	int drop=dropMessage(P);	//if we drop the message, we simply return otherwise we handle the message
	if(drop==1) return;

	if(buf[0]=='m')
	{
		//printf("$$%s$$\n",buf );
		HandleAppMsgRecv(buf,(struct sockaddr *)&source_addr,addrlen);		//Handle app message
	}

	if(buf[0]=='a')
	{
		HandleACKMsgRecv(buf);								//Handle ack message
	}

	return;
}

void HandleACKMsgRecv(char buf[MAX+7])		//Handle ack
{
	int id=getid(buf+1);	//get the id
	
	int i;
	for(i=0;i<MAX;i++)
	{
		if(notackmestb[i].id==id)
		{
			notackmestb[i].id=-1;	
			size_notackmestb--;
			break;
		}	
	}	
	
	return;		
}




void HandleAppMsgRecv(char buf[MAX+7], struct sockaddr *cliaddr, socklen_t clilen)
{
	char ack[8];							//acknowledgement msg
	char msg[MAX];
	int i;
	

	int id=getid(buf+1);
		

	if(recvmsgidtb[id-1] == 1)			//if the id has already been received
	{
		ack[0]='a';
		strncpy(ack+1,buf+1,6);
		ack[7]='\0';
		//printf("HandleAppMsgRecv1=%s %s\n",ack,buf);		
		sendto(sockfd_udp, ack, strlen(ack), 0, cliaddr, clilen);
		return;
	}
	
	for(i=0;buf[i+7]!='\0';i++)				//get the message
	{
		msg[i]=buf[i+7];
	}
	msg[i]='\0';
	
	strcpy(recvbuffer[queue1.recvbuffer_addend].msg,msg);		//storing it in the receive buffer
	recvbuffer[queue1.recvbuffer_addend].addr = *cliaddr;
	push();
	

	//send an ack
	ack[0]='a';
	strncpy(ack+1,buf+1,6);
	ack[7]='\0';
	
	sendto(sockfd_udp, ack, strlen(ack), 0, cliaddr, clilen);		
	recvmsgidtb[id-1] = 1;

	return;
}



void handle_alarm(int sig){
	//printf("Hello\n");
    HandleReceive();
    HandleRetransmit();
    HandleTransmit();
}



void run()
{
	struct itimerval it_val;
    signal(SIGALRM, handle_alarm);
    it_val.it_value.tv_sec = 1;
    it_val.it_value.tv_usec = 0;  
    it_val.it_interval = it_val.it_value;
    setitimer(ITIMER_REAL, &it_val, NULL);
    return ; 
}


int r_socket(int dom, int type, int prot)
{
	if(type!=SOCK_MRP)
		{
			return -1;
		}
	sockfd_udp=socket(dom,SOCK_DGRAM,prot);	//create udp socket
	if(sockfd_udp<0) return -1;

	srand(time(0));

	
	size_notackmestb=0;
	available_id = 0;
	transmissions = 0;
	queue1.recvbuffer_recvend=0;
	queue1.recvbuffer_addend=0;
	sendbuffer_size=0;

	//Allocate dynamically space to buffers
	recvbuffer=(struct recvmsg *)malloc(MAX*sizeof(struct recvmsg));
	sendbuffer=(struct sendmsg *)malloc(MAX*sizeof(struct sendmsg));
	notackmestb=(struct notackmes *)malloc(MAX*sizeof(struct notackmes ));
	recvmsgidtb=(int *)malloc(MAX*sizeof(int));

	for(int i=0; i<MAX; i++)
	{	
		recvmsgidtb[i]=0;
		sendbuffer[i].id=-1;
		notackmestb[i].id=-1;
	}	
	//return socket id
	run();

	return sockfd_udp;	
}


int r_sendto(int sockfd_udp, const void *b, size_t len, int flags, const struct sockaddr *dest_addr, socklen_t addrlen)
{

	check=1;
	char *buf=(char *)b;
	//printf("$%s\n$",buf );
	char msg[107];			//Msg of 107 bytes
	//int r;
	memset(msg,0,107);
	//printf("$%s$\n",msg );
	int i;
	//printf("$%ld$\n",len );
	for(i=0;i<len;i++)
		{
			msg[i+7]=buf[i];		//store message
		}	
	
	assign_id(msg,'m',available_id);
	//printf("r_sendto=%s %d\n",msg,available_id);

	while(sendbuffer_size>=MAX);

	for(i=0;i<MAX;i++)
	{
		if(sendbuffer[i].id==-1) 
		{
                //printf("success %d\n",i);
				sendbuffer[i].id=available_id;
				strcpy(sendbuffer[i].msg,msg);
				sendbuffer[i].addr=*dest_addr;
				sendbuffer_size++;
				break;
		}
			
		
	}		
	
	available_id=(available_id+1)%MAX;		//available_id is incremented	
	return 0;
}


int r_recvfrom(int sockfd_udp, char *buf, size_t len, int flags, struct sockaddr *source_addr, socklen_t *addrlen){
	int i;
	//printf("%s\n",buf);
	if(flags==MSG_DONTWAIT)													//If we use MSG_DONTWAIT flag
	{
		if(queue1.recvbuffer_recvend==queue1.recvbuffer_addend)				//receive buffer is empty
		{
			source_addr=NULL;
			addrlen=NULL;
			memset(buf,'\0',len);					
			return -1;								
		}

	}
	if(flags!=MSG_DONTWAIT)				//wait for the message
	{
		while(1)
		{
			if(queue1.recvbuffer_recvend==queue1.recvbuffer_addend)
			{
				sleep(1);		//sleep till the recv buffer is empty
			} 
			else break;
		}
	}

	
	int msglen=strlen(recvbuffer[queue1.recvbuffer_recvend].msg);
	int returnlen;


	if(msglen>=len)
	{
		
		for(i=0;i<len;i++) buf[i]=recvbuffer[queue1.recvbuffer_recvend].msg[i];		//copy the first len characters if msg is greater than len
		*source_addr=recvbuffer[queue1.recvbuffer_addend].addr;
		*addrlen=sizeof(*source_addr);
		queue1.recvbuffer_recvend=(queue1.recvbuffer_recvend+1)%MAX;			
		returnlen=(int)len;
		
		return returnlen;							
	}

	if(msglen<len)					//if the msg is smaller than the requested number of bytes
	{
		
		strcpy(buf,recvbuffer[queue1.recvbuffer_recvend].msg);	
		*source_addr=recvbuffer[queue1.recvbuffer_recvend].addr;	
		returnlen=strlen(buf);				
		pop();
	
		return returnlen;					
	}

	

	return -1;
}



int r_close(int sockfd_udp)
{
	while(1)
	{
		if(size_notackmestb==0 && sendbuffer_size==0) break;	//if notackmestable is not empty, wait
		else sleep(1);
	}
    //printf("number=%d\n",sendbuffer_size);

	if(check==1)
	{
		sendto(sockfd_udp,"CLOSING",7,MSG_DONTWAIT,(const struct sockaddr *)&addr1, sizeof(addr1));
		//printf("n=%d\n",n);

	}	
    free(sendbuffer);
	free(recvbuffer);			//free the buffers
	if(check==1)
	{	
		free(notackmestb);			
		free(recvmsgidtb);
	}
	printf("Closing Socket\n");
	int n=close(sockfd_udp);			//close the socket
	if(n<0) return -1;
	else return transmissions;
}



int dropMessage(float p)			//Drop a message
{
	float random=(float)rand()/(float)RAND_MAX;		
	if(random<p) return 1;				//droping iff the value is less than p
	else return 0;						//else do not drop
}

