
#include <stdio.h> 
#include <string.h> 
#include <sys/types.h>
#include <arpa/inet.h>
#include<stdlib.h>
#include "rsocket.h"


#define MAX 100 
#define ROLLNO 30008


int main(int argc,  char **argv ) { 
  
    struct sockaddr_in mesg_addr; 
    socklen_t len; 
    char buffer[MAX] ;
	
    memset(&mesg_addr, 0, sizeof(mesg_addr)); 
     int k=0;	
    // Creating socket file descriptor 
    int sockfd = r_socket(AF_INET, SOCK_MRP, 0);
    if ( sockfd < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 

    mesg_addr.sin_family = AF_INET;
    mesg_addr.sin_port = htons(5000 + 2 * ROLLNO +1);
    mesg_addr.sin_addr.s_addr = INADDR_ANY; 

    if (r_bind(sockfd, (const struct sockaddr *)&mesg_addr, sizeof(mesg_addr)) < 0 ) { 
        perror("bind failed"); 
        r_close(sockfd);
        exit(EXIT_FAILURE); 
    }
    mesg_addr.sin_port = htons(5000 + 2 * ROLLNO);
   
    len = sizeof(mesg_addr);
    for(int i = 0;;i++){
        if(k!=0 && i==k+1)break;  
        int n = r_recvfrom(sockfd, (char *)buffer, MAX, 0,  ( struct sockaddr *) &mesg_addr, &len);
	//printf("n=%d\n",n);
        if(n==1)  
        	printf("%s\n",buffer);
        //printf("n=%d\n",n);
        if(n>=2)
        {
		//printf("%d\n",k);
		char msg[20];
                memset(msg,'\0',20);
             	strcpy(msg,buffer+1);     
		k=atoi(msg);
                //printf("%d\n",k);
				
        }   
        // fflush(stdout);
    }
    printf("Closing the connection(Takes time to close as it has to handle duplicates)\n");
    r_recvfrom(sockfd, (char *)buffer, MAX, 0,  ( struct sockaddr *) &mesg_addr, &len);	
    r_close(sockfd); 
    return 0; 
}
