#include "myl.h"
#define FLOAT_DECIMAL_PLACES 6 

int printInt(int n)
{
    char buff[20], zero='0';
    int i=0, j, k, bytes;
    if(n==0) buff[i++] = zero;
    else{
        if(n<0){ // Handle case for negative.
            buff[i++] = '-';
            n = -n;
        }
        while(n){ // Enter individual digits into an array
            int dig=n%10;
            buff[i++] = (char)(zero+dig);
            n/=10;
        }

        if(buff[0] == '-')j=1;
        else j=0;
        k = i - 1;

        while(j<k){ // Switch the msb into first and lsb into last
            char temp=buff[j];
            buff[j++]=buff[k];
            buff[k--]=temp;
        }
    }

    bytes = i; // Print the integer
    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(buff), "d"(bytes)
    );
    if (bytes == 0) return ERR;

    return bytes;
}

int printStr(char * str)
{
    int len = 0; // len keeps count of number of characters printed

    while(str[len] != '\0')
        len++;

    // print the string
    __asm__ __volatile__ (
    "movl $1, %%eax \n\t"
    "movq $1, %%rdi \n\t"
    "syscall \n\t"
    :
    :"S"(str), "d"(len)
    );

    return len;
}

int printFlt(float f)
{
    int len = 0;  // len keeps count of number of characters printed

    if (f < 0)   // Handling the case if floating point number is negative
    {
        printStr("-");
        len++;
        f = -f;
    }

    int int_part = (int)f, i=0;  // Printing part the integer part of the number
    if (int_part == 0)
        len += printInt(0);
    else
        len += printInt(int_part);

    len += printStr(".");    // Printing decimal point

    f = f - int_part;
    char decimal_part[FLOAT_DECIMAL_PLACES + 1]; // Printing the fractional part from here, upto FLOAT_DECIMAL_PLACES
    while(i < FLOAT_DECIMAL_PLACES)
    {
        f *= 10;
        decimal_part[i] = (int) f + '0';
        f -= (int) f;
        i++;
    }
    decimal_part[FLOAT_DECIMAL_PLACES] = '\0';
    len += printStr(decimal_part);

    return len;
}

int readInt(int *n)
{
    char buff[100];
    int num_chars_in, input_num = 0;
    // take input 
    asm volatile(
        "syscall"
        : "=a" (num_chars_in)
        : "0" (0), "D" (0), "S" (buff), "d" (sizeof(buff))
        : "rcx", "r11", "memory", "cc"
    );

    int i = 0, is_negative = 0;

    while(buff[i] == ' ') // Remove spaces 
        i++;

    if (i == num_chars_in) return ERR; // if input only spaces received then err.

    if (buff[i] == '-') // Handle negatives
    {
        i++;
        is_negative = 1;
        while(buff[i] == ' ') // Handle spaces
            i++;

        if (i == num_chars_in) return ERR; // if input only spaces received then err.
    }

    int num_iter = 0;
    for(; i < num_chars_in; i++) // Iterated through input
    {
        if (buff[i] >= '0' && buff[i] <= '9') // Raise ERR or exit based on input character
        {
            input_num *= 10;
            input_num += buff[i] - '0';
            // printInt(input_num);
            // printStr("\n");
        }
        else
        {
            if (num_iter == 0)
                return ERR;  
            else
                break;
        }
        num_iter += 1;
    }
    if (is_negative == 1) // Handle negatives 
        input_num *= -1;

    *n = input_num;
    return OK;
}


int readFlt(float *f)
{
    char buff[100];
    int num_chars_in;
    long double input_num = 0;

    // Take input
    asm volatile(
        "syscall"
        : "=a" (num_chars_in)
        : "0" (0), "D" (0), "S" (buff), "d" (sizeof(buff))
        : "rcx", "r11", "memory", "cc"
    );

    int i = 0, is_negative = 0;

    while(buff[i] == ' ') // Handle spaces
        i++;

    if (i == num_chars_in) return ERR; // if input only spaces received then err.

    if (buff[i] == '-')
    {
        i++;
        is_negative = 1;
        while(buff[i] == ' ')
            i++;

        if (i == num_chars_in) return ERR; // if input only spaces after - received then err.
    }

    int num_iter = 0;
    for(; i < num_chars_in; i++) // Handle decimal part
    {
        if (buff[i] >= '0' && buff[i] <= '9')
        {
            input_num *= 10;
            input_num += buff[i] - '0';
        }
        else
        {
            break;
        }
        num_iter += 1;
    }

    float frac = 0.1;

    if(buff[i] == '.' )
    {
        i++;
        // Handle the fractional part
        for(; i < num_chars_in; i++)
        {
            if (buff[i] >= '0' && buff[i] <= '9')
            {
                input_num += frac * (buff[i] - '0');
                frac *= 0.1;
            }
            else
            {
                if (num_iter == 0)
                    return ERR;  
                else
                    break;
            }
            // printFlt(input_num);
            // printStr("\n");
            num_iter += 1;
        }
    }
    // printFlt(input_num);
    // printStr("\n");

    if (num_iter == 0)
        return ERR; 

    *f = input_num;

    if (is_negative == 1)
        *f *= -1;

    return OK;
}
