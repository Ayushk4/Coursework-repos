//void printi(int);
int hello(int p){
	printi(p[0]);
	return 0;
}
int main(){
	int a[1];
	a[0]=65;
	hello(a);	
	return 0;
}