int main()
{
   int n, i = 3, count, c,aaa,flag=0,bbb;
   prints("Enter the number of prime numbers required\n");
   readi(&n);
   int k = 0;
   if ( n >= 1 )
   {
      // k++;
      prints("First ");
      printi(n);
      prints(" prime numbers are :\n");
      prints("2\n");
   }
 
   for ( count = 2 ; count <= n ;  count++)
   {
      for ( c = 2 ; c < i ; c++ )
      {
         if ( i%c == 0 )
            flag++;
      }
      if(flag == 0)
      {
         printi(i);
         prints("\n");
      }else{
         count--;
      }
      i++;
      flag=0;
      
   }
   return 0;
}
