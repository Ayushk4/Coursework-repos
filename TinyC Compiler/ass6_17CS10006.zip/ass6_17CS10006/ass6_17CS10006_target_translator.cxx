#include "ass6_17CS10006_translator.h"
#include "y.tab.h"

extern Quad quad;

void incre(int *i){
	*i=(*i)+1;
	return ;
}
void initialiaz(int* i,int k){
	*i=k;
	return;
}
int trut(bool b){
	int c;
	if(b){
		c=1;
	}
	else c=0;
	return c;
}
void glo_tem(){
	int i=2;
	while(i--){
		i--;
	}
}

void SymbolTable::get_gotos()
{
	//Traverse in all the quads and add all the gotos
	int i;
	initialiaz(&i,0);
	for(;i < quad.quadarray.size(); incre(&i))
	{

		bool a1=quad.quadarray[i].op == o_GOTO || (quad.quadarray[i].op >= o_JLT && quad.quadarray[i].op <= o_JNE);
		int a2=0;
		a2=trut(a1);
		
		switch(a2)
		{
			//simple GOTO or Relational Operators
			case 1:gotos.insert(atoi(quad.quadarray[i].result.c_str()));
				break;
			case 0:a2=0;
				break;
		}

		// if(quad.quadarray[i].op == o_GOTO || (quad.quadarray[i].op >= o_JLT && quad.quadarray[i].op <= o_JNE) )
		// {
		// 	//simple GOTO or Relational Operators
		// 	gotos.insert(atoi(quad.quadarray[i].result.c_str()));
		// }
	}
}
void SymbolTable::set_activation_offsets()
{
	//offsets of Parameters and the local variables are to be changed here
	int i,pos,param_size=0;
	initialiaz(&i,1);
	for(;i<table.size() && table[i]->var_type == "param";incre(&i))
	{
		// Scan and add sizes of all the parameters
		//table[i]->size = 8;//table[i]->size * 2;
		param_size += table[i]->size;
	}
	//change the offsets of the rest of the variables
	printf("Param Size=%d\n",param_size);
	
	initialiaz(&pos,i);
	for(;i<table.size();incre(&i))
	{
		//Local Variables
		table[i]->offset = param_size - table[i]->size - table[i]->offset - 4;
	}
	initialiaz(&i,1);
	for(;i<pos;incre(&i))
	{
		//Params
		// table[i]->offset = param_size - table[i]->offset + table[0]->size + 4;
		table[i]->offset = ((pos-1)*4 - table[i]->offset + table[0]->size + 4)*2;
	}
	//Global Offset
	offset = offset - param_size - table[0]->size + 12;
}

void SymbolTable::generate_prologue(FILE *fp)
{
	fprintf(fp,"\t.text\n\t.globl\t%s\n\t.type\t%s,  @function\n",name.c_str(),name.c_str());
	//print label
	fprintf(fp,"%s:\n",name.c_str());
	//Push rbp and shift current esp to rbp
	//fprintf(fp,"LFB0:\n");
	fprintf(fp,"\tpushq\t%%rbp\n\tmovq\t%%rsp,  %%rbp\t\n");
	//Create space for the local variables
	fprintf(fp,"\tsubq\t$%d, %%rsp\n",offset);
}

void SymbolTable::print_internal_code(FILE *fp)
{
	/*Get quads one by one and start printng their assembly output*/
	int i, noOfParam, i_param;				// Variable for iterating between the function quads
	/*Assign all arrays with their address locations*/
	/*for(i = 1;i < table.size();i++)
	{
		if(table[i]->type!= NULL && table[i]->type->baseType == t_ARRAY)
		{
			fprintf(fp,"#;Array : %s\n",table[i]->name.c_str());
			fprintf(fp,"\tleal\t%d(%%rbp), %%eax\n",table[i]->offset);
			fprintf(fp,"\tmovl\t%%eax, %d(%%rbp)\n",table[i]->offset);
		}
	}*/
	/*Get Quad one by one and then start printing their assembly code*/
	initialiaz(&i,start_quad);
	for(; i <= end_quad; incre(&i))
	{
		opcodeType &opx = quad.quadarray[i].op;
		string &arg1x = quad.quadarray[i].arg1;
		string &arg2x = quad.quadarray[i].arg2;
		string &resx = quad.quadarray[i].result;
		int offr,off1,off2;
		fprintf(fp,"#; %d:",i);
		if(search(resx))
		{
			offr = search(resx)->offset;
			fprintf(fp,"res =  %s ",search(resx)->name.c_str());
		}
		bool a1=search(arg1x);
		int a2=trut(a1);
		switch (a2)
		{
			case 1:
			off1 = search(arg1x)->offset;
			fprintf(fp,"arg1 =  %s ",search(arg1x)->name.c_str());
			break;
			case 0:
			break;
		}
		// if(search(arg1x))
		// {
		// 	off1 = search(arg1x)->offset;
		// 	fprintf(fp,"arg1 =  %s ",search(arg1x)->name.c_str());
		// }
		if(search(arg2x))
		{
			off2 = search(arg2x)->offset;
			fprintf(fp," arg2 = %s ",search(arg2x)->name.c_str());
		}
		fprintf(fp,"\n");

		bool a3=gotos.find(i)!=gotos.end();
		int a4=trut(a3);
		switch (a4)
		{
			//Generate Label here
			case 1:
			fprintf(fp," .L%d:\n",i);
			break;
			case 0:
			break;
		}

		// if(gotos.find(i)!=gotos.end())
		// {
		// 	//Generate Label here
		// 	fprintf(fp," .L%d:\n",i);
		// }
		if (opx == o_PLUS){
				a4=1;
		}	
		else if (opx == o_MINUS) {
				a4=2;
			}
			else if (opx == o_MULT) {
				a4=3;
			}
			else if (opx == o_DIV)  {
				a4=4;
			}
			else if (opx == o_MOD)  {
				a4=5;
			}
			else if (opx == o_UMINUS) {
				a4=6;
			}
			else if (opx == o_COPY)		{
				a4=7;
			}
			else if (opx == o_PARAM)  {
				a4=8;
			}
			else if (opx == o_GOTO)  {
				a4=9;
			}
			else if (opx == o_CALL)  {
				a4=10;
				
			}
			// If and GOTO
			else if (opx == o_JLT)  {
				a4=11;
			}
			else if (opx == o_JLE)  {
				a4=12;
			}
			else if (opx == o_JGT)  {
				a4=13;
			}
			else if (opx == o_JGE)
			{
				a4=14;
			}
			else if (opx == o_JE)  {
				a4=15;
			}
			else if (opx == o_JNE)
			{
				a4=16;
			}
			else if (opx == o_ADDR)  {
				a4=17;
			}
			else if (opx == o_LDEREF)  {
				a4=18;
			}
			else if (opx == o_RDEREF)  {
				a4=19;
			}
			else if (opx == o_RINDEX)  {
				a4=20;
			}
			else if (opx == o_LINDEX)  {
				a4=21;
			}
			else if (opx == o_RET) {
				a4=22;
			}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
	switch (a4){
		case 1:
				// Copy values in eax and edx, add both of them to eax then move it to destination
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
				if(arg2x[0]>='0' && arg2x[0]<='9')
					fprintf(fp," \tmovl\t$%s, %%edx\n",arg2x.c_str());
				else
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
				fprintf(fp," \taddl\t%%edx,  %%eax\n");
				fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
				break;
		case 2:
				if(search(resx)->type->baseType == t_CHAR)
				{
					glo_tem();
					fprintf(fp,"\tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp,"\tmovzbl\t%d(%%rbp),  %%edx\n",off2);
					fprintf(fp,"\tsubl\t%%edx,  %%eax\n");
					fprintf(fp,"\tmovb\t%%al,  %d(%%rbp)\n",offr);
				}
				else
				{
					glo_tem();
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					// Direct Number access
					if(arg2x[0]>='0' && arg2x[0]<='9')
						fprintf(fp," \tmovl\t$%s, %%edx\n",arg2x.c_str());
					else
						fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp,"\tsubl\t%%edx, %%eax\n");
					fprintf(fp,"\tmovl\t%%eax, %d(%%rbp)\n",offr);
				}
				break;
			
			case 3:
				fprintf(fp," \tmovl\t%d(%%rbp),  %%eax\n",off1);
				if(arg2x[0]>='0' && arg2x[0]<='9')
				{
					fprintf(fp," \timull\t$%s,  %%eax, %%eax\n",arg2x.c_str());
					//fprintf(fp,"\timull\t%%ecx\n");
				}
				else
					fprintf(fp,"\timull\t%d(%%rbp),  %%eax\n",off2);
				fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
				break;
			
			case 4:
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
				fprintf(fp," \tcltd\n ");
				fprintf(fp," \tidivl\t%d(%%rbp)\n ",off2);
				fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
				break;
			
			case 5:
				fprintf(fp,"\tmovl\t%d(%%rbp),  %%eax\n",off1);
				fprintf(fp," \tcltd\n");
				fprintf(fp," \tidivl\t%d(%%rbp)\n",off2);
				fprintf(fp," \tmovl\t%%edx, %d(%%rbp)\n",offr);
				break;
			case 23:
				glo_tem();
				break;
			
			case 6:
				fprintf(fp," \tmovl\t%d(%%rbp),  %%eax\n",off1);
				fprintf(fp," \tnegl\t%%eax\n ");
				fprintf(fp," \tmovl\t%%eax,  %d(%%rbp)\n ",offr);
				break;
			
			case 7:
				//Check if the second argument is a constant
				if(arg1x[0]>='0' && arg1x[0]<='9')	//first character is number
				{
					fprintf(fp," \tmovl\t$%s,  %d(%%rbp)\n",arg1x.c_str(),offr);
				}
				else if(arg1x[0] == '\'')
				{
					//Character
					glo_tem();
					fprintf(fp," \tmovb\t$%d,  %d(%%rbp)\n",(int)arg1x[1],offr);
				}
				else if(search(resx)->type->baseType == t_CHAR)
				{
					glo_tem();
					fprintf(fp," \tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp," \tmovb\t%%al,  %d(%%rbp)\n",offr);
				}
				else if(search(resx)->type->baseType == t_PTR)
				{
					glo_tem();
					fprintf(fp," \tmovq\t%d(%%rbp), %%rax\n",off1);
					fprintf(fp," \tmovq\t%%rax, %d(%%rbp)\n",offr);
				}
				else
				{
					glo_tem();
					fprintf(fp,"\tmovl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
				}
				break;
			
			case 8:
				if(resx[0] == '_')
				{
					//string
					char* temp = (char*)resx.c_str();
					fprintf(fp," \tmovq\t$.STR%d,\t%%rdi\n",atoi(temp+1));
				}
				else if(search(resx)->type->baseType == t_ARRAY)
				{
					//Array
					glo_tem();
					fprintf(fp," \tleaq\t%d(%%rbp), %%rax\n",offr);
					fprintf(fp," \tpushq\t%%rax\n");
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",offr);
					fprintf(fp," \tpushq\t%%rax\n");
				}
				break;
			
			case 9:
				fprintf(fp," \tjmp .L%s\n",resx.c_str());
				break;
			
			case 10:
				//fprintf(fp, "##arg1x%s\n", arg2x.c_str() );
				if(arg1x == "printi")
				{
					glo_tem();
					string &resultx = quad.quadarray[i-1].result;
					int offer = search(resultx)->offset;
					fprintf(fp," \tmovl\t%d(%%rbp), %%edi\n",offer);
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, " \tpopq\t%%rax\n");
				}
				else if(arg1x == "readi")
				{
					glo_tem();
					string &resultx = quad.quadarray[i-1].result;
					int offer = search(resultx)->offset;
					fprintf(fp," \tmovq\t%d(%%rbp), %%rdi\n",offer);
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, " \tpopq\t%%rax\n");
				}
				else if(arg1x == "prints")
				{
					glo_tem();
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
					fprintf(fp," \tmovl\t$0, %%eax\n");
				}
				else
				{
					glo_tem();
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
					fprintf(fp," \tmovl\t$0, %%eax\n");
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, "\tpopq\t%%rax\n");
				}
				
				break;
			case 24:
				glo_tem();
				break;
			case 11:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjl  .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjl .L%s\n",resx.c_str());
				}
				break;
			
			case 12:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjle .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjle .L%s\n",resx.c_str());
				}
				break;
			
			case 13:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjg .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjg .L%s\n",resx.c_str());
				}
				break;
			
			case 14:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjge .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp,"\tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjge .L%s\n",resx.c_str());
				}
				break;
			
			case 15:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tje .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp,"\tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx,  %%eax\n");
					fprintf(fp,"\tje  .L%s\n",resx.c_str());
				}
				break;
			case 25:
				glo_tem();
				break;
			case 16:
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp),  %%al\n",off2);
					fprintf(fp," \tjne .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx,  %%eax\n");
					fprintf(fp,"  \tjne .L%s\n",resx.c_str());
				}
				break;
			
			case 17:
				fprintf(fp," \tleaq\t%d(%%rbp), %%rax\n",off1);
				fprintf(fp," \tmovq\t%%rax, %d(%%rbp)\n",offr);
				break;
			
			case 18:
				fprintf(fp," \tmovq\t%d(%%rbp), %%rax\n",off1);
				fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",offr);
				fprintf(fp," \tmovl\t%%edx,  (%%rax)\n");
				break;
			
			case 19:
				fprintf(fp," \tmovq\t%d(%%rbp),  %%rax\n",off1);
				fprintf(fp,"\tmovl\t(%%rax),  %%eax\n");
				fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
				break;
			
			case 20:
				// Get Address, subtract offset, get memory
				fprintf(fp," \tleaq\t%d(%%rbp), %%rdx\n",off1);
				fprintf(fp," \taddq\t%d(%%rbp), %%rdx\n",off2);
				if(search(resx)->type->baseType == t_CHAR)
				{
					glo_tem();
					fprintf(fp," \tmovzbl\t(%%rdx),  %%eax\n");
					fprintf(fp," \tmovb\t%%al, %d(%%rbp)\n",offr);
				}
				else
				{
					fprintf(fp," \tmovl\t(%%rdx), %%eax\n");
					fprintf(fp," \tmovl\t%%eax,   %d(%%rbp)\n",offr);
				}
				break;
			case 26:
				glo_tem();
				break;
			case 21:
				// Get Address, subtract offset, get memory
				fprintf(fp," \tleaq\t%d(%%rbp), %%rdx\n",offr);
				fprintf(fp," \taddq\t%d(%%rbp), %%rdx\n",off1);
				if(search(resx)->type->baseType == t_CHAR)
				{
					glo_tem();
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off2);
					fprintf(fp," \tmovb\t%%al, (%%rdx)\n");
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off2);
					fprintf(fp," \tmovl\t%%eax, (%%rdx)\n");
				}
				break;
			
			case 22:
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",offr);
				generate_epilogue(fp);
				break;
			default :
				break;
	}
	
	}
}

void SymbolTable::generate_epilogue(FILE *fp)
{
	//Restore the stack pointer and the base pointer
	fprintf(fp,"#;  Func Epilogue\n");
	fprintf(fp," \taddq\t$%d,  %%rsp\n",offset);
	fprintf(fp,"\tmovq\t%%rbp,  %%rsp\n");
	fprintf(fp," \tpopq\t%%rbp\n");
	fprintf(fp," \tret\n");
	fprintf(fp,"#;  Func End\n");
}



