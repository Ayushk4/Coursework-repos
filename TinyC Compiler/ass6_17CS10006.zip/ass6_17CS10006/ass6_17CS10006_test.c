enum week{Sunday, Monday, Tuesday,Wednesday};


inline int fact(int a)
{
    if(a<=1)
        return 1;              
    return a*fact(a-1);
}


int main()
{
    auto int a = 5e0, i;
    const double d = .9e-14;
    long long int k = fact(a+1.);
    printf("%lld\n",k);
    for(int i=0;i<4;i++)
        printf("%d\n",i);

    int arr[] = {1,2,3,4,5,6};
    int j = 5E0;

    int m = 1;
    int n = TEN;
    m |= n;
    m = m*n;
    m <<= 2;
    m = -n;

    double aa = 5*3%6+2*7.0, bb = sizeof(int);

    unsigned int l = -10;

    IF:if(a <= d)
        printf("yes\n");
    else if(a && d)
        printf("no\n");



    switch(a){
        case 1: printf("");
            break;
        default: printf("");
    }

    goto IF;

    do{
        temp->data = j;
        temp->next = NULL;
        (*temp1).next = temp;
        temp1 = temp;
        if(j == 2)
            continue;
    }while(j>=1);

    char ch = 'd';

    return 0;
}
