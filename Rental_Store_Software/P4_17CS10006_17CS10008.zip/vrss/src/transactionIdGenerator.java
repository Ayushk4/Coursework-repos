//class containing the id of current transaction 
public class transactionIdGenerator 
{
    static
    {
        transactionID=1;
        plID=1;
    }
    public static int transactionID;//ID of transaction in Records.records
    public static int plID;//ID of transaction in Account.plAccount
}
