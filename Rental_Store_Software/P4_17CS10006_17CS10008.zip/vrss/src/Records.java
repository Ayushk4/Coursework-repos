import java.util.ArrayList;
import java.util.List;

//contains a list containing all the transactions
public class Records 
{
    public static List<Transaction> records=new ArrayList<>();
    //records list stores all the transaction
}
