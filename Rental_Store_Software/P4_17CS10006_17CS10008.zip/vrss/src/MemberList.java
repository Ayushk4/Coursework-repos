
import java.util.ArrayList;
import java.util.List;

//contains a list to store all the member objects created
public class MemberList 
{
    public static List<Member> memberList=new ArrayList<>();
    // for storing customers
}
