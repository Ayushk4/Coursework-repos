Initialisation

MySql
1. Create a new user with username="newuser" and password="password" .
2. Create a new Database "newdb" 

Netbeans
1. Download a MySql-java-connector (link:https://mvnrepository.com/artifact/mysql/mysql-connector-java)
2. Add the downloaded jar file to the library.
   2a. Right click on the project name and click properties.
   2b. click on "library" button
   2c. browse the downloaded jar file and click on "add jar" option

Running the Application
1. Open terminal and Run the command "mysql -u newuser -p" and enter password
2. Run the the main file using Netbeans
3. A window appears and the application runs.

Key Featues:
Video Rental Store Software allows effective management of a Video Rental Store. It keeps track of customer details and their transactions. It also stores the details of the items and keep record of its format and type.

Extra Features:
1. Auto complete: Shows Drop down menu containing the best match for a query.
2. Levenshtein Distance: This distance is used to enhance the search of items in the list
3. Premium Customer: extra option for premium customer. 

Working of the application

1. At the start of the execution the entries from the database are loaded into the corresponding arraylists in java programme. The first window that appears is a login window which allows manager as well as storekeeper to login.
2. Seocnd window appears depending on whether manager has logged in or storekeeper has logged in.
	2a. Various options are made available to manager in the form of radio buttton. Choosing any one of which opens another window .
	2b. Similarly options are made available to storekeeper in the form of radio buttton. Choosing any one of which opens another window and so on.
