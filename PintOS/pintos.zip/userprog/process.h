#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

#define CMD_ARGS_MAX 30
#define CMD_LENGTH_MAX 100

struct fd_entry
{
  int fd;
  struct file *file;
  struct list_elem elem;
};

tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (int status);
void process_activate (void);

int allocate_fd (void);
struct fd_entry* get_fd_entry(int fd);

#endif /* userprog/process.h */
