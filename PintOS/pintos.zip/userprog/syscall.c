#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "userprog/process.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "devices/shutdown.h"

static void syscall_handler (struct intr_frame *);
static bool str_is_valid(void *str);

void syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

	
/* Reads a byte at user virtual address UADDR.
   UADDR must be below PHYS_BASE.
   Returns the byte value if successful, -1 if a segfault
   occurred. */
static int get_user (const uint8_t *uaddr)
{
  int result;
  asm ("movl $1f, %0; movzbl %1, %0; 1:"
       : "=&a" (result) : "m" (*uaddr));
  return result;
}

static bool ptr_is_valid(void *ptr, uint8_t argc)
{
	uint8_t i = 0;
	uint8_t *j = NULL;
  while (i < argc)
  {
    j = ((uint8_t *)ptr)+i;
    if (!is_user_vaddr(j) || (get_user(j) == -1))
    { 
    	return false;
    }
   	++i;
  }
  return true;
}

static bool str_is_valid(void *str)
{
  int ch = -1;
  do 
  {
  	ch = get_user((uint8_t *)str);
  	str++;
  } while(ch != '\0' && ch != -1);
  
  if(ch!='\0') 
  	return false; 
  else  
  	return true;
}



///////////////////
// SYS_EXIT
///////////////////

static bool syscall_exit_handler(struct intr_frame * f)
{
	//printf("exit\n");
  if(ptr_is_valid(f->esp + 4, 4))
  {
  	int status = *((int*)f->esp+1);
    thread_exit(status);
    return true;
  }
  return false;
}




////////////////////
// SYS_OPEN
////////////////////

static bool syscall_open_handler(struct intr_frame * f)
{
	//printf("open\n");
  if (ptr_is_valid(f->esp + 4, 4))
  {
    char **c = (char **)(f->esp + 4);
    if (str_is_valid(*c))
    {
      struct file *fil = filesys_open (*c);
      if (fil == NULL)
        return false;

      struct fd_entry *fd_ptr = malloc (sizeof(struct fd_entry));
      if (fd_ptr == NULL)
        return false;

      fd_ptr->fd = allocate_fd();
      fd_ptr->file = fil;
      list_push_back(&thread_current()->desc_table, &fd_ptr->elem);

      return true;
    }
  }
  return false;
}


////////////////////
// SYS_CLOSE
////////////////////

static bool syscall_close_handler(struct intr_frame * f)
{
	//printf("close\n");
  if (ptr_is_valid(f->esp + 4, 4))
  {
    int fd;
    fd = *(int *)(f->esp + 4);

    if (get_fd_entry(fd) != NULL)
    {
      struct fd_entry *fd_ptr = get_fd_entry(fd);
      file_close(fd_ptr->file);
      list_remove(&fd_ptr->elem);
      free(fd_ptr);
      return true;
    }
  }
  return false;
}




////////////////////
// SYS_READ
////////////////////

static bool syscall_read_handler(struct  intr_frame *f)
{
  // Read takes args a file desc, a buffer, and size count to read;
  //printf("read\n");
  if (ptr_is_valid(f->esp + 4, 12))
  {
    unsigned count = *(unsigned *)(f->esp + 12);
    char * output_buffer = *(char**)(f->esp + 8);

    if (ptr_is_valid((void *)(output_buffer), 1)
        && ptr_is_valid((void *)(output_buffer) + count, 1))
    {
      int fd = *(int *)(f->esp + 4);
      struct fd_entry  *fd_ptr = get_fd_entry(fd);
      
      if (fd_ptr == NULL)
      { 
      	f->eax = -1;  // return false; ????
      }
      else
      {
        f->eax = file_read(fd_ptr->file, (void *) output_buffer, count);
      }
    	return true;
    }
  }
  return false;
}



///////////////////
// SYS_WRITE
///////////////////

static bool syscall_write_handler(struct  intr_frame *f)
{
  // Write takes args a file desc, a buffer, and size count to write;
  //printf("write\n");
  if (ptr_is_valid(f->esp + 4, 12))
  {
  	int fd = *(int *)(f->esp + 4);
  	void *buffer = *(char **)(f->esp + 8);
    unsigned count = *(unsigned *)(f->esp + 12);
    if (ptr_is_valid(buffer, 1) && ptr_is_valid((buffer + count), 1))
    {
      if (fd == 1) // STDOUT
      {
        putbuf(buffer, (size_t)count);
        f->eax = (int)count;
      }
      else // Not STDOUT
      {
        struct fd_entry  *fd_ptr = get_fd_entry(fd);
        if (fd_ptr == NULL)
        { 
        	f->eax = -1;
        } // Unable to read
        else
        { 
        	f->eax = file_write(fd_ptr->file, (void *) buffer, count);
        }
      }
      return true;
    }
  }
  return false;
}




///////////////////
// SYS_CREATE
///////////////////

static bool syscall_create_handler(struct intr_frame * f)
{
	//printf("create\n");
  if (ptr_is_valid(f->esp +4, 4))
  {
    char ** string_ptr_ptr = (char **) (f->esp + 4);
    char * file_name = * string_ptr_ptr;

    if (str_is_valid(file_name))
    {
      unsigned initial_size;
      if (ptr_is_valid(f->esp + 8, 4))
      {
        initial_size = * (int *)(f->esp + 8);
        f->eax = filesys_create(file_name, initial_size);
        return true;
      }
    }
  }
  
  return false;
}




///////////////////
// SYS_REMOVE
///////////////////

static bool syscall_remove_handler(struct intr_frame * f)
{
	//printf("remove\n");
  if (ptr_is_valid(f->esp +4, 4))
  {
    char ** string_ptr_ptr = (char **) (f->esp + 4);
    char * file_name = * string_ptr_ptr;

    if (str_is_valid(file_name))
    {
      f->eax = filesys_remove(file_name);
      return true;
    }
  }
  
  return false;
}


////////////////////
// SYS_FILESIZE
////////////////////

static bool syscall_filesize_handler(struct intr_frame * f)
{
	//printf("filesize\n");
  if (ptr_is_valid(f->esp+4, 4))
  {
    int fd = *(int *)(f->esp + 4);
    struct fd_entry *fd_ptr = get_fd_entry(fd);
    if (fd_ptr != NULL)
    {
      f->eax = file_length(fd_ptr->file);
      return true;
    }
  }
  return false;
}


static void syscall_handler (struct intr_frame *f)
{
  if(ptr_is_valid(f->esp, 4) && 
      ((*(int *)f->esp >= SYS_EXIT && *(int *)f ->esp <= SYS_CLOSE))) // If we decide to add funcationalities for mkdir, chdir, then this need to be changed.
  {
    int c = *(int *)f->esp;
    bool success = true;
    switch (c)
    {
      case SYS_EXIT:
        success = syscall_exit_handler(f);
        break;
      case SYS_OPEN:
        success = syscall_open_handler(f);
        break;
      case SYS_READ:
        success = syscall_read_handler(f);
        break;
      case SYS_WRITE:
        success = syscall_write_handler(f);
        break;
      case SYS_CLOSE:
        success = syscall_close_handler(f);
        break;
      case SYS_CREATE:
      	success = syscall_create_handler(f); 
      	break;
     	case SYS_REMOVE: 
        success = syscall_remove_handler(f); 
        break;
      case SYS_FILESIZE:
        success = syscall_filesize_handler(f);
        break;
      default:
        success = false;
        break;
    }
    if (!success)
    	thread_exit(0);
  }
  else
  { 
  	thread_exit (-1); 
  }
}


